/* ===================== Juego: Sushi Go! ===================== */
window.PuntacosGames = window.PuntacosGames || {};

(function () {
  const GAME_ID = 'sushi-go';
  const ROUNDS_TOTAL = 3;
  const CARDS_BY_PLAYER_COUNT = { 2: 10, 3: 9, 4: 8, 5: 7 };
  const DOT_COLORS = ['#f43f5e', '#f59e0b', '#22c55e', '#6c63ff', '#06b6d4'];

  function cardsForCount(n) { return CARDS_BY_PLAYER_COUNT[n] || null; }
  function esc(v) { return window.escapeHtml ? window.escapeHtml(v) : String(v); }

  function emptyCards() {
    return {
      maki1: 0, maki2: 0, maki3: 0,
      tempura: 0, sashimi: 0, gyoza: 0,
      pudding: 0,
      nigiriSquid: 0, nigiriSalmon: 0, nigiriEgg: 0,
      nigiriSquidWasabi: 0, nigiriSalmonWasabi: 0, nigiriEggWasabi: 0,
      wasabi: 0,
      chopsticks: 0
    };
  }

  function normaliseCards(raw) {
    const out = emptyCards();
    Object.keys(out).forEach((key) => { out[key] = Math.max(0, Number(raw && raw[key]) || 0); });
    return out;
  }

  // Physical cards: a nigiri placed on wasabi consumes 2 cards (wasabi + nigiri).
  function cardCount(c) {
    return c.maki1 + c.maki2 + c.maki3 + c.tempura + c.sashimi + c.gyoza + c.pudding +
      c.nigiriSquid + c.nigiriSalmon + c.nigiriEgg +
      (c.nigiriSquidWasabi * 2) + (c.nigiriSalmonWasabi * 2) + (c.nigiriEggWasabi * 2) +
      c.wasabi + c.chopsticks;
  }

  function makiIcons(c) { return c.maki1 + (c.maki2 * 2) + (c.maki3 * 3); }

  function baseScore(c) {
    const tempura = Math.floor(c.tempura / 2) * 5;
    const sashimi = Math.floor(c.sashimi / 3) * 10;
    const gyozaTable = [0, 1, 3, 6, 10, 15];
    const gyoza = gyozaTable[Math.min(c.gyoza, 5)] || 15;
    const nigiri = (c.nigiriSquid * 3) + (c.nigiriSalmon * 2) + c.nigiriEgg +
      (c.nigiriSquidWasabi * 9) + (c.nigiriSalmonWasabi * 6) + (c.nigiriEggWasabi * 3);
    return tempura + sashimi + gyoza + nigiri;
  }

  function makiScores(players, cards) {
    const eligible = players.map((name) => ({ name, icons: makiIcons(cards[name]), has: (cards[name].maki1 + cards[name].maki2 + cards[name].maki3) > 0 }))
      .filter((x) => x.has).sort((a, b) => b.icons - a.icons);
    const scores = Object.fromEntries(players.map((p) => [p, 0]));
    if (!eligible.length) return scores;

    const top = eligible[0].icons;
    const first = eligible.filter((x) => x.icons === top);
    if (first.length > 1) {
      const points = Math.floor(6 / first.length);
      first.forEach((x) => { scores[x.name] += points; });
      return scores;
    }
    scores[first[0].name] += 6;

    const second = eligible.find((x) => x.icons < top);
    if (second) {
      const tiedSecond = eligible.filter((x) => x.icons === second.icons);
      const points = Math.floor(3 / tiedSecond.length);
      tiedSecond.forEach((x) => { scores[x.name] += points; });
    }
    return scores;
  }

  function roundScores(players, cards) {
    const maki = makiScores(players, cards);
    return Object.fromEntries(players.map((name) => [name, baseScore(cards[name]) + maki[name]]));
  }

  function puddingScores(players, puddingTotals) {
    const scores = Object.fromEntries(players.map((p) => [p, 0]));
    const values = players.map((p) => ({ name: p, count: Number(puddingTotals[p]) || 0 }));
    const max = Math.max(...values.map((x) => x.count));
    const min = Math.min(...values.map((x) => x.count));
    const most = values.filter((x) => x.count === max);
    const least = values.filter((x) => x.count === min);
    if (most.length < players.length) {
      const pts = Math.floor(6 / most.length);
      most.forEach((x) => { scores[x.name] += pts; });
    }
    if (least.length < players.length) {
      const pts = Math.floor(6 / least.length);
      least.forEach((x) => { scores[x.name] -= pts; });
    }
    return scores;
  }

  function configScreen(container, roster, onStart) {
    const counts = [2, 3, 4, 5];
    let count = Math.min(Math.max(roster.length || 2, 2), 5);
    if (!counts.includes(count)) count = 2;
    const currentNames = [];
    for (let i = 0; i < 5; i++) currentNames[i] = roster[i] || '';

    function renderSlot(i) {
      const color = DOT_COLORS[i % DOT_COLORS.length];
      const displayName = currentNames[i] || `Jugador ${i + 1}`;
      return `<div class="sg-player-slot sg-player-slot-tap" data-i="${i}"><span class="sg-dot" style="background:${color}"></span><span class="sg-player-name-display ${!currentNames[i] ? 'placeholder' : ''}">${esc(displayName)}</span><span class="sg-slot-chevron">›</span></div>`;
    }
    function playerSlotsHtml() { let html = ''; for (let i = 0; i < count; i++) html += renderSlot(i); return html; }
    function regenerateSlots() { container.querySelector('#sg_player_slots').innerHTML = playerSlotsHtml(); }
    function cardsInfoHtml() { const cards = cardsForCount(count); return `Con ${count} jugadores, cada uno recibe <strong>${cards} cartas</strong> por ronda.`; }

    function openPlayerSheet(i) {
      const overlay = document.createElement('div');
      overlay.className = 'sg-sheet-overlay';
      overlay.innerHTML = `<div class="sg-sheet"><div class="sg-sheet-handle"></div><div class="sg-sheet-title">Elegir jugador</div><div class="sg-sheet-list">${roster.map((name, ri) => `<div class="sg-sheet-row" data-name="${esc(name)}"><span class="sg-dot" style="background:${DOT_COLORS[ri % DOT_COLORS.length]}"></span><span class="sg-sheet-row-name">${esc(name)}</span>${name === currentNames[i] ? '<span class="sg-sheet-check">✓</span>' : ''}</div>`).join('') || '<p class="pc-muted">Aún no tienes jugadores guardados.</p>'}</div><div class="sg-sheet-new"><input class="pc-input" id="sg_sheet_new_input" placeholder="O escribe un nombre nuevo" style="margin:0;"><button class="pc-btn" id="sg_sheet_new_btn">Añadir y elegir</button></div><div id="sg_sheet_error" class="pc-muted" style="color:var(--danger);margin-top:6px"></div></div>`;
      document.body.appendChild(overlay);
      requestAnimationFrame(() => overlay.classList.add('open'));
      function close() { overlay.classList.remove('open'); setTimeout(() => overlay.remove(), 200); }
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelectorAll('.sg-sheet-row').forEach((row) => row.addEventListener('click', () => { currentNames[i] = row.dataset.name; regenerateSlots(); close(); }));
      const input = overlay.querySelector('#sg_sheet_new_input');
      const error = overlay.querySelector('#sg_sheet_error');
      input.addEventListener('input', () => { error.textContent = ''; });
      overlay.querySelector('#sg_sheet_new_btn').addEventListener('click', () => {
        const val = input.value.trim();
        if (!val) { error.textContent = 'Escribe un nombre para el jugador.'; return; }
        if (roster.some((n) => n.trim().toLowerCase() === val.toLowerCase())) { error.textContent = `Ya existe un jugador llamado "${val}".`; return; }
        if (window.Store) {
          const globalPlayers = window.Store.getPlayers();
          if (!globalPlayers.some((n) => n.trim().toLowerCase() === val.toLowerCase())) { globalPlayers.push(val); window.Store.setPlayers(globalPlayers); }
        }
        roster.push(val); currentNames[i] = val; regenerateSlots(); close();
      });
    }

    container.innerHTML = `<div class="sg-section-label">Número de jugadores</div><div class="sg-count-row" id="sg_count_row">${counts.map((n) => `<button type="button" class="sg-count-pill ${n === count ? 'active' : ''}" data-n="${n}">${n}</button>`).join('')}</div><div class="sg-section-label" style="margin-top:14px">Jugadores guardados</div><div id="sg_player_slots">${playerSlotsHtml()}</div><div class="sg-config-row" style="margin-top:14px"><label class="sg-config-label">Etiqueta de la partida (opcional)</label><input class="pc-input" id="sg_tag" placeholder="Ej. Sushi del viernes"></div><div class="sg-section-label">Reparto de cartas</div><div class="pc-card" id="sg_cards_info"><p class="pc-muted" style="margin:0" id="sg_cards_info_text">${cardsInfoHtml()}</p></div><div class="sg-section-label" style="margin-top:14px">Rondas</div><div class="pc-card"><p class="pc-muted" style="margin:0">Sushi Go! se juega a <strong>${ROUNDS_TOTAL} rondas</strong>.</p></div><button class="pc-btn full-margin" id="sg_start_btn">Iniciar partida →</button>`;
    container.querySelectorAll('.sg-count-pill').forEach((btn) => btn.addEventListener('click', () => { count = parseInt(btn.dataset.n, 10); container.querySelectorAll('.sg-count-pill').forEach((b) => b.classList.toggle('active', b === btn)); regenerateSlots(); container.querySelector('#sg_cards_info_text').innerHTML = cardsInfoHtml(); }));
    container.querySelector('#sg_player_slots').addEventListener('click', (e) => { const slot = e.target.closest('.sg-player-slot-tap'); if (slot) openPlayerSheet(parseInt(slot.dataset.i, 10)); });
    container.querySelector('#sg_start_btn').addEventListener('click', () => {
      const players = []; for (let i = 0; i < count; i++) players.push((currentNames[i] || '').trim() || `Jugador ${i + 1}`);
      if (window.Store) { const newRoster = window.Store.getPlayers().slice(); players.forEach((name) => { if (!newRoster.some((n) => n.trim().toLowerCase() === name.toLowerCase())) newRoster.push(name); }); window.Store.setPlayers(newRoster); }
      onStart({ cardsPerPlayer: cardsForCount(count), roundsTotal: ROUNDS_TOTAL }, container.querySelector('#sg_tag').value.trim(), players);
    });
  }

  function playScreen(container, players, config, savedState, callbacks) {
    let state = savedState || { round: 1, cardLimit: config.cardsPerPlayer, cardsRegistered: {}, cards: {}, rounds: [], totals: {}, finished: false };
    state.round = Number(state.round) || 1;
    state.cardLimit = Number(state.cardLimit) || config.cardsPerPlayer;
    state.cardsRegistered = state.cardsRegistered || {};
    state.cards = state.cards || {};
    state.rounds = Array.isArray(state.rounds) ? state.rounds : [];
    state.totals = state.totals || {};
    state.puddingTotals = state.puddingTotals || {};
    players.forEach((p) => { state.cards[p] = normaliseCards(state.cards[p]); state.cardsRegistered[p] = cardCount(state.cards[p]); state.totals[p] = Number(state.totals[p]) || 0; state.puddingTotals[p] = Number(state.puddingTotals[p]) || 0; });

    function save() { players.forEach((p) => { state.cards[p] = normaliseCards(state.cards[p]); state.cardsRegistered[p] = cardCount(state.cards[p]); }); callbacks.onStateChange(state); }
    function currentRoundScores() { return roundScores(players, state.cards); }

    const groups = [
      { title: 'MAKIS', items: [['maki1', '🍣 1 Maki'], ['maki2', '🍣 2 Makis'], ['maki3', '🍣 3 Makis']] },
      { title: 'OTRAS CARTAS', items: [['tempura', '🍤 Tempura'], ['sashimi', '🐟 Sashimi'], ['gyoza', '🥟 Gyoza']] },
      { title: 'NIGIRIS', items: [['nigiriSquid', '🦑 Nigiri Calamar'], ['nigiriSalmon', '🐟 Nigiri Salmón'], ['nigiriEgg', '🍳 Nigiri Tortilla'], ['nigiriSquidWasabi', '🦑 Calamar + Wasabi'], ['nigiriSalmonWasabi', '🐟 Salmón + Wasabi'], ['nigiriEggWasabi', '🍳 Tortilla + Wasabi']] },
      { title: 'ESPECIALES', items: [['wasabi', '🟩 Wasabi'], ['chopsticks', '🥢 Palillos']] },
      { title: 'PUDINES', items: [['pudding', '🍮 Pudin']] }
    ];

    function openCardSheet(name) {
      const cards = state.cards[name];
      const overlay = document.createElement('div'); overlay.className = 'sg-sheet-overlay';
      overlay.innerHTML = `<div class="sg-sheet sg-card-sheet"><div class="sg-sheet-handle"></div><div class="sg-sheet-title">Anotar cartas · ${esc(name)}</div><div class="sg-sheet-card-count" id="sg_sheet_count"></div><div class="sg-card-groups">${groups.map((g) => `<div class="sg-card-group"><div class="sg-section-label">${g.title}</div><div class="sg-card-entry-grid">${g.items.map(([key, label]) => `<div class="sg-entry-card"><div class="sg-entry-title">${label}</div>${key === 'wasabi' ? '<div class="sg-entry-subtitle">Wasabi suelto · 1 carta · 0 pts</div>' : key === 'nigiriSquidWasabi' ? '<div class="sg-entry-subtitle">Wasabi + Nigiri · 2 cartas · 9 pts</div>' : key === 'nigiriSalmonWasabi' ? '<div class="sg-entry-subtitle">Wasabi + Nigiri · 2 cartas · 6 pts</div>' : key === 'nigiriEggWasabi' ? '<div class="sg-entry-subtitle">Wasabi + Nigiri · 2 cartas · 3 pts</div>' : key === 'nigiriSquid' ? '<div class="sg-entry-subtitle">1 carta · 3 pts</div>' : key === 'nigiriSalmon' ? '<div class="sg-entry-subtitle">1 carta · 2 pts</div>' : key === 'nigiriEgg' ? '<div class="sg-entry-subtitle">1 carta · 1 pt</div>' : '<div class="sg-entry-subtitle">&nbsp;</div>'}<div class="sg-entry-controls"><button class="sg-step" data-key="${key}" data-delta="-1">−</button><strong id="sg_${key}">0</strong><button class="sg-step" data-key="${key}" data-delta="1">+</button></div></div>`).join('')}</div></div>`).join('')}</div><div class="sg-sheet-score" id="sg_sheet_score"></div><div id="sg_sheet_error" class="pc-muted" style="color:var(--danger);margin-top:8px"></div><button class="pc-btn full-margin" id="sg_save_cards">Guardar cartas</button></div>`;
      document.body.appendChild(overlay); requestAnimationFrame(() => overlay.classList.add('open'));
      const draft = normaliseCards(cards); const countBox = overlay.querySelector('#sg_sheet_count'); const scoreBox = overlay.querySelector('#sg_sheet_score'); const errorBox = overlay.querySelector('#sg_sheet_error');
      function renderDraft() {
        Object.keys(draft).forEach((key) => { const el = overlay.querySelector('#sg_' + key); if (el) el.textContent = draft[key]; });
        const total = cardCount(draft); const icons = makiIcons(draft); const score = baseScore(draft);
        countBox.textContent = `${total}/${state.cardLimit} cartas · ${icons} iconos Maki`;
        scoreBox.textContent = `Puntos propios ahora: ${score} · Maki se compara al cerrar la ronda`;
        overlay.querySelectorAll('.sg-step[data-delta="1"]').forEach((btn) => { btn.disabled = total >= state.cardLimit; });
      }
      function close() { overlay.classList.remove('open'); setTimeout(() => overlay.remove(), 200); }
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelectorAll('.sg-step').forEach((btn) => btn.addEventListener('click', () => { const key = btn.dataset.key; const delta = parseInt(btn.dataset.delta, 10); const next = draft[key] + delta; if (next < 0) return; const nextTotal = cardCount(draft) + (delta * (key.includes('Wasabi') ? 2 : 1)); if (nextTotal > state.cardLimit) { errorBox.textContent = `No puedes superar las ${state.cardLimit} cartas de esta ronda.`; return; } errorBox.textContent = ''; draft[key] = next; renderDraft(); }));
      overlay.querySelector('#sg_save_cards').addEventListener('click', () => { Object.assign(cards, draft); save(); close(); render(); });
      renderDraft();
    }

    function closeRound() {
      const counts = players.map((p) => cardCount(state.cards[p]));
      if (counts.some((n) => n !== state.cardLimit)) { window.alert(`Cada jugador debe tener exactamente ${state.cardLimit} cartas físicas antes de cerrar la ronda.`); return; }
      const scores = currentRoundScores();
      players.forEach((p) => { state.totals[p] += scores[p]; });
      state.rounds.push({ round: state.round, scores });
      if (state.round >= config.roundsTotal) {
        players.forEach((p) => { state.puddingTotals[p] += state.cards[p].pudding; });
        const pudding = puddingScores(players, state.puddingTotals);
        players.forEach((p) => { state.totals[p] += pudding[p]; });
        state.finalPudding = pudding;
        state.finished = true;
        const results = players.map((name) => ({ name, score: state.totals[name], pudding: state.puddingTotals[name] }))
          .sort((a, b) => b.score - a.score || b.pudding - a.pudding);
        save();
        callbacks.onFinish(results);
        return;
      }
      state.round += 1;
      players.forEach((p) => { state.puddingTotals[p] += state.cards[p].pudding; state.cards[p] = emptyCards(); });
      save(); render();
    }

    function render() {
      const scores = currentRoundScores();
      const rows = players.map((name) => { const cards = state.cards[name]; const reg = cardCount(cards); const icons = makiIcons(cards); return `<div class="sg-player-card"><div class="sg-player-top"><span class="sg-dot" style="background:${window.avatarColor ? window.avatarColor(name) : '#f43f5e'};width:14px;height:14px"></span><span class="sg-player-name">${esc(name)}</span><span class="sg-card-count">${reg} / ${state.cardLimit}</span></div><div class="sg-player-summary"><span>🍣 ${icons} makis</span><span>🍤 ${cards.tempura} tempura</span><span>🦑 ${cards.nigiriSquid + cards.nigiriSquidWasabi} calamar</span><span>🟩 ${cards.wasabi} suelto</span><span>🍮 ${state.puddingTotals[name] + cards.pudding} pudin</span></div><div class="sg-player-round-score">Ronda: <strong>${scores[name]}</strong> pts · Total: <strong>${state.totals[name]}</strong></div><button class="pc-btn sg-score-btn" data-player="${esc(name)}">Anotar cartas</button></div>`; }).join('');
      container.innerHTML = `<div class="sg-header"><div class="pc-title" style="margin-bottom:2px">Sushi Go!</div><div class="pc-muted">Ronda ${state.round}/${config.roundsTotal} · ${state.cardLimit} cartas por jugador</div></div>${rows}<button class="pc-btn full-margin sg-round-btn" id="sg_close_round">${state.round >= config.roundsTotal ? 'Finalizar partida' : 'Cerrar ronda →'}</button>`;
      container.querySelectorAll('.sg-score-btn').forEach((btn) => btn.addEventListener('click', () => openCardSheet(btn.dataset.player)));
      container.querySelector('#sg_close_round').addEventListener('click', closeRound);
    }
    save(); render();
  }

  window.PuntacosGames[GAME_ID] = { id: GAME_ID, name: 'Sushi Go!', icon: '🍣', desc: 'Reparte, elige y puntúa', gradient: 'linear-gradient(135deg, #f43f5e, #fb7185)', minPlayers: 2, maxPlayers: 5, configScreen, playScreen };
})();
