/* ===================== Juego: Sushi Go! ===================== */
/* Implementación del contrato de juego documentado en la cabecera de
   shell.js (window.PuntacosGames[id] = {...}).

   FASE 1 — solo estructura. Esta fase NO implementa ninguna lógica de
   puntuación ni de cartas (Maki, Tempura, Sashimi, Gyoza, Nigiri, Wasabi,
   Palillos, Pudin). Eso llega en una fase posterior.

   `config` de este juego: { cardsPerPlayer, roundsTotal }
   `state` de este juego: { round, cardLimit, cardsRegistered, rounds }
     - round:           ronda actual (1..roundsTotal)
     - cardLimit:        cartas FÍSICAS repartidas esta ronda (depende del
                          número de jugadores, igual en las 3 rondas)
     - cardsRegistered:  { [nombreJugador]: number } — cartas físicas ya
                          registradas en la ronda actual. OJO: en fases
                          futuras una sola acción (p.ej. Nigiri + Wasabi)
                          podrá consumir más de 1 carta física a la vez, así
                          que este contador cuenta CARTAS, no "acciones" ni
                          "pulsaciones". No asumas una equivalencia 1:1.
     - rounds:           historial de rondas ya cerradas de ESTA partida
                          (vacío en Fase 1; se rellenará cuando exista el
                          cierre de ronda en una fase posterior)
   El Shell no conoce ni depende de ninguno de los dos formatos anteriores. */
window.PuntacosGames = window.PuntacosGames || {};

(function () {
  const GAME_ID = 'sushi-go';
  const ROUNDS_TOTAL = 3;
  const CARDS_BY_PLAYER_COUNT = { 2: 10, 3: 9, 4: 8, 5: 7 };
  const DOT_COLORS = ['#f43f5e', '#f59e0b', '#22c55e', '#6c63ff', '#06b6d4'];

  function cardsForCount(n) {
    return CARDS_BY_PLAYER_COUNT[n] || null;
  }

  function esc(v) {
    return window.escapeHtml ? window.escapeHtml(v) : String(v);
  }

  /* ---------------- Config screen ---------------- */
  function configScreen(container, roster, onStart) {
    const counts = Object.keys(CARDS_BY_PLAYER_COUNT).map(Number); // [2,3,4,5]
    let count = Math.min(Math.max(roster.length || 2, 2), 5);
    if (!counts.includes(count)) count = 2;
    const currentNames = [];
    for (let i = 0; i < 5; i++) currentNames[i] = roster[i] || '';

    function renderSlot(i) {
      const color = DOT_COLORS[i % DOT_COLORS.length];
      const displayName = currentNames[i] || `Jugador ${i + 1}`;
      return `
        <div class="sg-player-slot sg-player-slot-tap" data-i="${i}">
          <span class="sg-dot" style="background:${color}"></span>
          <span class="sg-player-name-display ${!currentNames[i] ? 'placeholder' : ''}">${esc(displayName)}</span>
          <span class="sg-slot-chevron">›</span>
        </div>
      `;
    }

    function playerSlotsHtml() {
      let html = '';
      for (let i = 0; i < count; i++) html += renderSlot(i);
      return html;
    }

    function regenerateSlots() {
      container.querySelector('#sg_player_slots').innerHTML = playerSlotsHtml();
    }

    function cardsInfoHtml() {
      const cards = cardsForCount(count);
      return `Con ${count} jugador${count === 1 ? '' : 'es'}, cada uno recibe <strong>${cards} cartas</strong> por ronda.`;
    }

    function openPlayerSheet(i) {
      const overlay = document.createElement('div');
      overlay.className = 'sg-sheet-overlay';
      overlay.innerHTML = `
        <div class="sg-sheet">
          <div class="sg-sheet-handle"></div>
          <div class="sg-sheet-title">Elegir jugador</div>
          <div class="sg-sheet-list">
            ${roster.map((name, ri) => `
              <div class="sg-sheet-row" data-name="${esc(name)}">
                <span class="sg-dot" style="background:${DOT_COLORS[ri % DOT_COLORS.length]}"></span>
                <span class="sg-sheet-row-name">${esc(name)}</span>
                ${name === currentNames[i] ? '<span class="sg-sheet-check">✓</span>' : ''}
              </div>
            `).join('') || '<p class="pc-muted">Aún no tienes jugadores guardados.</p>'}
          </div>
          <div class="sg-sheet-new">
            <input class="pc-input" id="sg_sheet_new_input" placeholder="O escribe un nombre nuevo" style="margin:0;">
            <button class="pc-btn" id="sg_sheet_new_btn">Añadir y elegir</button>
          </div>
          <div id="sg_sheet_error" class="pc-muted" style="color:var(--danger); margin-top:6px;"></div>
        </div>
      `;
      document.body.appendChild(overlay);
      requestAnimationFrame(() => overlay.classList.add('open'));

      function close() {
        overlay.classList.remove('open');
        setTimeout(() => overlay.remove(), 200);
      }

      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelectorAll('.sg-sheet-row').forEach((row) => {
        row.addEventListener('click', () => {
          currentNames[i] = row.dataset.name;
          regenerateSlots();
          close();
        });
      });

      const newInput = overlay.querySelector('#sg_sheet_new_input');
      const errorBox = overlay.querySelector('#sg_sheet_error');
      newInput.addEventListener('input', () => { errorBox.textContent = ''; });
      overlay.querySelector('#sg_sheet_new_btn').addEventListener('click', () => {
        const val = newInput.value.trim();
        if (!val) {
          errorBox.textContent = 'Escribe un nombre para el jugador.';
          return;
        }
        const isDuplicate = roster.some((n) => n.trim().toLowerCase() === val.toLowerCase());
        if (isDuplicate) {
          errorBox.textContent = `Ya existe un jugador llamado "${val}".`;
          return;
        }
        currentNames[i] = val;
        regenerateSlots();
        close();
      });
    }

    container.innerHTML = `
      <div class="sg-section-label">Número de jugadores</div>
      <div class="sg-count-row" id="sg_count_row">
        ${counts.map((n) => `<button type="button" class="sg-count-pill ${n === count ? 'active' : ''}" data-n="${n}">${n}</button>`).join('')}
      </div>

      <div class="sg-section-label" style="margin-top:14px;">Jugadores guardados</div>
      <div id="sg_player_slots">${playerSlotsHtml()}</div>

      <div class="sg-config-row" style="margin-top:14px;">
        <label class="sg-config-label">Etiqueta de la partida (opcional)</label>
        <input class="pc-input" id="sg_tag" placeholder="Ej. Sushi del viernes">
      </div>

      <div class="sg-section-label">Reparto de cartas</div>
      <div class="pc-card" id="sg_cards_info">
        <p class="pc-muted" style="margin:0;" id="sg_cards_info_text">${cardsInfoHtml()}</p>
      </div>

      <div class="sg-section-label" style="margin-top:14px;">Rondas</div>
      <div class="pc-card">
        <p class="pc-muted" style="margin:0;">Sushi Go! se juega a <strong>${ROUNDS_TOTAL} rondas</strong>.</p>
      </div>

      <button class="pc-btn full-margin" id="sg_start_btn">Iniciar partida →</button>
    `;

    container.querySelectorAll('.sg-count-pill').forEach((btn) => {
      btn.addEventListener('click', () => {
        count = parseInt(btn.dataset.n, 10);
        container.querySelectorAll('.sg-count-pill').forEach((b) => b.classList.toggle('active', b === btn));
        regenerateSlots();
        container.querySelector('#sg_cards_info_text').innerHTML = cardsInfoHtml();
      });
    });

    container.querySelector('#sg_player_slots').addEventListener('click', (e) => {
      const tapSlot = e.target.closest('.sg-player-slot-tap');
      if (tapSlot) openPlayerSheet(parseInt(tapSlot.dataset.i, 10));
    });

    container.querySelector('#sg_start_btn').addEventListener('click', () => {
      const players = [];
      for (let i = 0; i < count; i++) {
        players.push((currentNames[i] || '').trim() || `Jugador ${i + 1}`);
      }

      // Guarda/actualiza el roster con los nombres usados en esta partida (igual que Anotador Universal)
      const newRoster = (window.Store ? window.Store.getPlayers() : roster).slice();
      for (let i = 0; i < count; i++) newRoster[i] = players[i];
      if (window.Store) window.Store.setPlayers(newRoster);

      const tag = container.querySelector('#sg_tag').value.trim();
      const config = {
        cardsPerPlayer: cardsForCount(count),
        roundsTotal: ROUNDS_TOTAL
      };
      onStart(config, tag, players);
    });
  }

  /* ---------------- Play screen (Fase 1: solo estructura) ---------------- */
  function playScreen(container, players, config, savedState, callbacks) {
    let state = savedState;
    if (!state) {
      state = {
        round: 1,
        cardLimit: config.cardsPerPlayer,
        cardsRegistered: {},
        rounds: []
      };
      players.forEach((p) => { state.cardsRegistered[p] = 0; });
      callbacks.onStateChange(state);
    } else {
      // Salvaguarda mínima: si el estado guardado no conoce a algún jugador
      // (no debería ocurrir en esta fase), se añade con 0 cartas registradas.
      players.forEach((p) => { if (!(p in state.cardsRegistered)) state.cardsRegistered[p] = 0; });
    }

    function render() {
      const rows = players.map((name) => {
        const color = window.avatarColor ? window.avatarColor(name) : '#f43f5e';
        const reg = state.cardsRegistered[name] || 0;
        return `
          <div class="sg-player-card">
            <div class="sg-player-top">
              <span class="sg-dot" style="background:${color}; width:14px; height:14px;"></span>
              <span class="sg-player-name">${esc(name)}</span>
              <span class="sg-card-count">${reg} / ${state.cardLimit}</span>
            </div>
            <div class="sg-categories-placeholder">🍣 Categorías de cartas — próximamente</div>
          </div>
        `;
      }).join('');

      container.innerHTML = `
        <div class="sg-header">
          <div class="pc-title" style="margin-bottom:2px;">Partida</div>
          <div class="pc-muted">Ronda ${state.round}/${config.roundsTotal}</div>
        </div>
        ${rows}
      `;
    }

    render();
  }

  window.PuntacosGames[GAME_ID] = {
    id: GAME_ID,
    name: 'Sushi Go!',
    icon: '🍣',
    desc: 'Reparte, elige y puntúa',
    gradient: 'linear-gradient(135deg, #f43f5e, #fb7185)',
    minPlayers: 2,
    maxPlayers: 5,
    configScreen: configScreen,
    playScreen: playScreen
  };
})();
